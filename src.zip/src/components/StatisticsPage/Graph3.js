import React, { useEffect, useState } from 'react';
import { BarChart, Bar, Cell, XAxis, ResponsiveContainer, YAxis, Tooltip } from 'recharts';
import axios from 'axios';

const colors = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', 'red', 'pink', 'blue', 'black'];

const getPath = (x, y, width, height) => {
  return `M${x},${y + height}C${x + width / 3},${y + height} ${x + width / 2},${y + height / 3}
  ${x + width / 2}, ${y}
  C${x + width / 2},${y + height / 3} ${x + (2 * width) / 3},${y + height} ${x + width}, ${y + height}
  Z`;
};

const TriangleBar = (props) => {
  const { fill, x, y, width, height } = props;

  return <path d={getPath(x, y, width, height)} stroke="none" fill={fill} />;
};

export default function Chart3(props) {
  const [donorData, setDonorData] = useState([]);
  const data = [];

  useEffect(() => {
    const fetchData = async () => {
      try {
        const result = await axios.get(`http://localhost:3001/count-by-blood-group?College=${props.college}`);
        const actualResult = Object.entries(result.data).map(([key, value]) =>
          key != "UnKnown"
            ? {
                name: key,
                pv: 0,
                count: value,
                amt: 0,
              }
            : {
                name: "U",
                pv: 0,
                count: value,
                amt: 0,
              }
        );
        setDonorData(actualResult);
      } catch (error) {
        setDonorData([
          {
            name: "O+",
            pv: 0,
            count: 0,
            amt: 0,
          },
        ]);
        console.error(error);
      }
    };

    fetchData();
  }, [props.college]);

  return (
    <>

    <ResponsiveContainer width="100%" height={300}>
      <BarChart
        data={donorData}
        margin={{
          top: 20,
          right: 30,
          left: 20,
          bottom: 5,
        }}
      >
        <XAxis dataKey="name" />
        <YAxis />
        <Tooltip cursor={false} />
        <Bar dataKey="pv" fill="#8884d8" shape={<TriangleBar />} label={{ position: 'top' }}>
          {data.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={colors[index % 8]} />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
    </>
  );
}

Chart3.demoUrl = 'https://codesandbox.io/p/sandbox/bar-chart-with-customized-shape-jpsj68';
