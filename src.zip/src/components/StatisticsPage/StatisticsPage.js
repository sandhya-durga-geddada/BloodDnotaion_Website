import React, { Fragment,useState,useEffect} from 'react';
import Header from '../../components/header/Header';
import PageTitle from '../../components/pagetitle/PageTitle';
import Scrollbar from '../../components/scrollbar/scrollbar';
import Footer from '../../components/footer/Footer';
import Graph1 from './Graph1';
import Graph2 from './Graph2';
import Graph3 from './Graph3';
import './charts.css';

import axios from 'axios';

const StatisticsPage = (props) => {
    const [collegesData, setColleges] = useState({});

    useEffect( () => { 
        axios.get("http://localhost:3001/count-by-department").then((result)=> {
            console.log(result.data);
            setColleges(result.data);
        })
    }, [])

    const CollegeName = {
        "": "All colleges",
        "AEC": "Aditya Engineering College",
        "ACOE":  "Aditya College of Engineering"
    }

    const [option, setOption] = useState('');
    const handleChange = (event) => {
        setOption(event.target.value);
    };

    return (
        <Fragment>
            <Header hclass={'header--styleFour'} />
            <main className='main'>
            <PageTitle pageTitle={'STATISTICS'} pagesub={'STATISTICS'} />
                <section className="about">
                   <div className="header-stat">
                        <div className='drop-down-clgs'>
                            <select value={option} onChange={handleChange} className='dropdown-btn'>
                                <option value="" className='dropdown-content'>All Colleges</option>

                                { Object.keys(collegesData).map(college => {
                                    return <option value={college} className='dropdown-content'>{college}</option>
                                })}

                                {/* <option value="Aditya University" className='dropdown-content'>Aditya University</option>
                                <option value="ACET" className='dropdown-content'>AEC</option>
                                <option value="ACOE" className='dropdown-content'>ACOE</option> */}
                            </select>
                        </div>
                    </div>
                    <div className='graph-container'>
                    <u style={{color:"black"}}> <h3 className="sectionTitle__big" >{CollegeName[option]}</h3></u>
                        <div className='Graphs-1'>
                            <Graph1 college = {option}/>
                        </div>
                        <div className='Graphs-2'>
                            <div className='Graph2-1'>
                            <Graph2 college = {option}/>
                            </div>
                            <div className='Graph2-2'>
                            <h3 className="chart-title">Blood Group Count</h3><br></br><br></br>
                            <Graph3 college = {option}/>
                            </div>
                        </div>
                    </div>
                </section>
            </main>
            <Footer />
            <Scrollbar />
        </Fragment>
    );
};

export default StatisticsPage;
