import React from 'react';
import { Link } from 'react-router-dom';
import shape from '../../images/shapes/footerShape2.png';
import logo from '../../images/logos/logo_2.jpg';

const ClickHandler = () => {
    window.scrollTo(10, 0);
}

const footerData = [
    {
        title: 'Home',
        link: '/home',
    },
    {
        title: 'Events',
        link: '/events',
    },
    {
        title: 'Statistics',
        link: '/stats',
    },
    {
        title: 'Donations',
        link: '/donation-listing',
        submenu: [
            {
                id: 31,
                title: 'Donations Process',
                link: '/donation-listing'
            },
            {
                id: 32,
                title: 'Our Volunteers',
                link: '/volunteers'
            }
        ]
    },
    {
        title: 'About',
        link: '/about',
    },
    {
        title: 'Contact',
        link: '/contact',
    }
];

const Footer = (props) => {
    return (
        <footer className="footer footer--bg footer--styleOne pt-70 pb-40">
            <img src={shape} alt="Gainioz Shape" className="footer__shape" />
            <div className="container">
                <div className="row align-items-center">
                    {/* <div className="col">
                        <div className="footer__logo">
                            <img src={logo} alt="Gainioz Logo" className="footer_logo_image" />
                        </div>
                    </div> */}
                    <div className="col">
                        <div className="footer__social itSocial">
                            <ul>
                                <li>
                                    <Link onClick={ClickHandler} className="facebook" to="/" rel="nofollow">
                                        <i className="fab fa-facebook-f"></i>
                                    </Link>
                                </li>
                                <li>
                                    <Link onClick={ClickHandler} className="twitter" to="/" rel="nofollow">
                                        <i className="fab fa-twitter"></i>
                                    </Link>
                                </li>
                                <li>
                                    <Link onClick={ClickHandler} className="instagram" to="/" rel="nofollow">
                                        <i className="fab fa-instagram"></i>
                                    </Link>
                                </li>
                                <li>
                                    <Link onClick={ClickHandler} className="linkedin" to="/" rel="nofollow">
                                        <i className="fab fa-linkedin-in"></i>
                                    </Link>
                                </li>
                                <li>
                                    <Link onClick={ClickHandler} className="pinterest" to="/" rel="nofollow">
                                        <i className="fab fa-youtube"></i>
                                    </Link>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div className="col-12">
                        <hr className="footer__line" />
                    </div>
                </div>
                <div className="row">
                    <div className="footer__middle pt-65 pb-35">
                        <div className="row justify-content-between">
                            {footerData.map((item, index) => (
                                <div className="col-lg-2 col-md-4 mb-30" key={index}>
                                    <div className="footer__widget">
                                        <div className="footer__title">
                                            <h2 className="footer__heading text-uppercase text-white">
                                                <Link onClick={ClickHandler} to={item.link}>{item.title}</Link>
                                            </h2>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
                <div className="row">
                    <div className="footer__bottom">
                        <div className="row">
                            <div className="col-12">
                                <hr className="footer__line" />
                            </div>
                            <div className="col mb-20">
                                <div className="footer__copyright pt-20">
                                    <p className="footer_copyright_text mb-0"><center>Copyright@2024 , Blood Donation Team, Designed By Technical Hub</center></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    );
}

export default Footer;