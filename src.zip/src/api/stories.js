import pImg1 from '../images/portfolio/portfolio-thumb1.jpg'
import pImg2 from '../images/portfolio/portfolio-thumb2.jpg'
import pImg3 from '../images/portfolio/portfolio-thumb3.jpg'
import pImg4 from '../images/portfolio/portfolio-thumb4.jpg'
import pImg5 from '../images/portfolio/portfolio-thumb5.jpg'
import pImg6 from '../images/portfolio/portfolio-thumb6.jpg'
import pImg7 from '../images/update/portfolio-thumb4.jpg'
import pImg8 from '../images/update/portfolio-thumb5.jpg'
import pImg9 from '../images/update/portfolio-thumb6.jpg'



const Stories = [
    {
        Id: '1',
        pImg: pImg1,
        title: 'Homeless People In africa',
        slug: 'Homeless-People-In-africa',
        description: 'Our all-encompassing IELTS Coaching curriculum encompasses every aspect...',
    },
    {
        Id: '2',
        pImg: pImg2,
        title: 'Homeless People In myanmar',
        slug: 'Homeless-People-In-myanmar',
        description: 'Our experienced coaches are not just educators; they are partners in your journey..',
    },
    {
        Id: '3',
        pImg: pImg3,
        title: 'Foodless People In Sudan',
        slug: 'Foodless-People-In-Sudan',
        description: 'The contents of the citizenship test typically cover a range of subjects ...',
    },
    {
        Id: '4',
        pImg: pImg4,
        title: 'Homeless People In Afgan',
        slug: 'Homeless-People-In-Afgan',
        description: 'Our all-encompassing IELTS Coaching curriculum encompasses every aspect...',
    },
    {
        Id: '5',
        pImg: pImg5,
        title: 'Waterless People In africa',
        slug: 'Waterless-People-In-africa',
        description: 'Our experienced coaches are not just educators; they are partners in your journey..',
    },
    {
        Id: '6',
        pImg: pImg6,
        title: 'Foodless People In India',
        slug: 'Foodless-People-In-India',
        description: 'The contents of the citizenship test typically cover a range of subjects ...',
    },
    {
        Id: '7',
        pImg: pImg7,
        title: 'Homeless People In Nigeria',
        slug: 'Homeless-People-In-nigeria',
        description: 'Our all-encompassing IELTS Coaching curriculum encompasses every aspect...',
    },
    {
        Id: '8',
        pImg: pImg8,
        title: 'Waterless People In Brasil',
        slug: 'Waterless-People-In-Brasil',
        description: 'Our experienced coaches are not just educators; they are partners in your journey..',
    },
    {
        Id: '9',
        pImg: pImg9,
        title: 'Foodless People In Srilanka',
        slug: 'Foodless-People-In-Srilanka',
        description: 'The contents of the citizenship test typically cover a range of subjects ...',
    },
]

export default Stories;