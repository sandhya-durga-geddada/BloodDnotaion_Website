import timg1 from '../images/volunteers/volunteer1.jpg'
import timg2 from '../images/volunteers/volunteer2.jpg'
import timg3 from '../images/volunteers/volunteer3.jpg'
import timg4 from '../images/volunteers/volunteer4.jpg'
import timg5 from '../images/volunteers/volunteer5.jpg'
import timg6 from '../images/volunteers/volunteer6.jpg'
import timg7 from '../images/volunteers/volunteer7.jpg'
import timg8 from '../images/volunteers/volunteer8.jpg'


const Teams = [
   {
      Id: '1',
      tImg: timg1,
      name: 'Cameron Williamson',
      slug: 'Cameron-Williamson',
      title: 'Systems Engineer',
   },
   {
      Id: '2',
      tImg: timg2,
      name: 'Orion Jasper',
      slug: 'Orion-Jasper',
      title: 'IT Consultant',
   },
   {
      Id: '3',
      tImg: timg3,
      name: 'August Everest',
      slug: 'August-Everest',
      title: 'systems engineer',
   },
   {
      Id: '4',
      tImg: timg4,
      name: 'Maverick Phoenix',
      slug: 'Maverick-Phoenix',
      title: 'data analyst',
   },
   {
      Id: '5',
      tImg: timg5,
      name: 'Daxton Atlas',
      slug: 'Daxton-Atlas',
      title: 'Project Manager',
   },
   {
      Id: '6',
      tImg: timg6,
      name: 'Guy Hawkins',
      slug: 'Guy-Hawkins',
      title: 'data analyst',
   },
   {
      Id: '7',
      tImg: timg7,
      name: 'Wade Warren',
      slug: 'Wade-Warren',
      title: 'Project Manager',
   },
   {
      Id: '8',
      tImg: timg8,
      name: 'Jenny Wilson',
      slug: 'Jenny-Wilson',
      title: 'data analyst',
   },
   
]

export default Teams;