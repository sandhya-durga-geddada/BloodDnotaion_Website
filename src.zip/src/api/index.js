import data from './data.json';

const fetchData = () => {
  return data;
};

export default fetchData;