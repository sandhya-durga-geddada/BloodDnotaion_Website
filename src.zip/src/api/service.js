import sImg1 from '../images/utilites/dontaion-details-thumb1.jpg'
import sImg2 from '../images/utilites/dontaion-details-thumb1.jpg'
import sImg3 from '../images/utilites/dontaion-details-thumb1.jpg'

import icon1 from '../images/icons/feature-icon-1.svg'
import icon2 from '../images/icons/feature-icon-2.svg'
import icon3 from '../images/icons/feature-icon-3.svg'
import icon4 from '../images/icons/feature-icon-4.svg'
import icon5 from '../images/icons/feature-icon-5.svg'
import icon6 from '../images/icons/feature-icon-6.svg'
import icon7 from '../images/icons/services-icon4.svg'




const Services = [
    {
        Id: '1',
        sImg:sImg1,
        icon:icon1,
        title: 'together Pledge',
        slug: 'together-Pledge',
        description:'We help local nonprofits access the funding, tools, training,',
    },
    {
        Id: '2',
        sImg:sImg2,
        icon:icon2,
        title: 'Donate for HOmless',
        slug: 'Donate-for-HOmless',
        description:'We help local nonprofits access the funding, tools, training,',
    },
    {
        Id: '3',
        sImg:sImg3,
        icon:icon3,
        title: 'Fundraise',
        slug: 'Fundraise',
        description:'We help local nonprofits access the funding, tools, training,',
    },
    {
        Id: '4',
        sImg:sImg3,
        icon:icon4,
        title: 'Water & Healthy Food',
        slug: 'Water-&-Healthy Food',
        description:'Simply dummy text of the printing and typesetting industry. Lorem Ipsum has been Simply dummy',
    },
    {
        Id: '5',
        sImg:sImg3,
        icon:icon5,
        title: 'Study & Life Tips',
        slug: 'Study-&-Life-Tips',
        description:'Simply dummy text of the printing and typesetting industry. Lorem Ipsum has been Simply dummy',
    },
    {
        Id: '6',
        sImg:sImg3,
        icon:icon6,
        title: 'Medical & Aid',
        slug: 'Medical-&-Aid',
        description:'Simply dummy text of the printing and typesetting industry. Lorem Ipsum has been Simply dummy',
    },
    {
        Id: '7',
        sImg:sImg3,
        icon:icon7,
        title: 'Build Home',
        slug: ' Build-Home',
        description:'Simply dummy text of the printing and typesetting industry. Lorem Ipsum has been Simply dummy',
    },
    {
        Id: '8',
        sImg:sImg3,
        icon:icon5,
        title: 'Study & Life Tips',
        slug: 'Study-&-Life-Tips',
        description:'Simply dummy text of the printing and typesetting industry. Lorem Ipsum has been Simply dummy',
    },
]    

export default Services;